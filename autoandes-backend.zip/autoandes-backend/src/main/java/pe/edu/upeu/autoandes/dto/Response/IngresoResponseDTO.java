package pe.edu.upeu.autoandes.dto.Response;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IngresoResponseDTO {
  private String codigo;

  private String servicio;

  private Long cantidadTotal;

  private BigDecimal importeTotal;
}
