package pe.edu.upeu.autoandes.service.service;

import pe.edu.upeu.autoandes.dto.Request.LoginRequestDTO;
import pe.edu.upeu.autoandes.dto.Response.LoginResponseDTO;
import pe.edu.upeu.autoandes.dto.Response.UsuarioResponseDTO;

public interface AuthService {
  LoginResponseDTO login(LoginRequestDTO d);

  UsuarioResponseDTO usuarioActual(String username);
}
