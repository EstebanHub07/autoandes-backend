package pe.edu.upeu.autoandes.service.service;

import pe.edu.upeu.autoandes.dto.Request.ServicioRequestDTO;
import pe.edu.upeu.autoandes.dto.Response.ServicioResponseDTO;
import pe.edu.upeu.autoandes.service.generic.CrudService;

public interface ServicioService
    extends CrudService<ServicioRequestDTO, ServicioResponseDTO, Long> {
  ServicioResponseDTO cambiarEstado(Long id, boolean activo);
}
