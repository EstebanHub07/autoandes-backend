package pe.edu.upeu.autoandes.service.service;

import java.util.List;

import pe.edu.upeu.autoandes.dto.Request.VehiculoRequestDTO;
import pe.edu.upeu.autoandes.dto.Response.VehiculoResponseDTO;
import pe.edu.upeu.autoandes.service.generic.CrudService;

public interface VehiculoService
    extends CrudService<VehiculoRequestDTO, VehiculoResponseDTO, Long> {
  List<VehiculoResponseDTO> buscarPorCliente(Long clienteId);
}
