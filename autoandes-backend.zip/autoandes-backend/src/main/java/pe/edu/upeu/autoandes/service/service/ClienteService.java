package pe.edu.upeu.autoandes.service.service;

import java.util.List;
import pe.edu.upeu.autoandes.dto.Response.ClienteResponseDTO;

public interface ClienteService {
  List<ClienteResponseDTO> readAll();
}
