package pe.edu.upeu.autoandes.security;

public enum Permiso {
  SERVICIO_LEER,
  SERVICIO_ESCRIBIR,
  VEHICULO_LEER,
  VEHICULO_ESCRIBIR,
  ORDEN_LEER,
  ORDEN_REGISTRAR,
  ORDEN_ANULAR,
  REPORTE_VER
}
