package pe.edu.upeu.autoandes.service.service;

import java.util.List;
import pe.edu.upeu.autoandes.dto.ClienteResponseDTO;

public interface ClienteService {
  List<ClienteResponseDTO> readAll();
}
